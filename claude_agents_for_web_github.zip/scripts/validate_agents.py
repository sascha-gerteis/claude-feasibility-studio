#!/usr/bin/env python3
"""Static validator for the Claude Feasibility Studio scaffold (no dependencies)."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
AGENTS = {
    "head-of-market-research", "investment-banking", "project-technology",
    "syndications", "real-estate-hospitality", "ai-strategy", "environmental-technologies"
}
REQUIRED = ["CLAUDE.md", "inputs/PROJECT_BRIEF.md", "prompts/START_FULL_STUDY.md", "templates/source_register.csv", "templates/assumption_register.csv"]
errors=[]
for fname in REQUIRED:
    if not (ROOT / fname).is_file(): errors.append(f"missing {fname}")
actual=set()
for path in (ROOT / '.claude' / 'agents').glob('*.md'):
    text=path.read_text(encoding='utf-8')
    match=re.match(r'^---\s*\n(.*?)\n---\s*\n',text,re.S)
    if not match: errors.append(f"bad frontmatter: {path.name}"); continue
    fm=match.group(1)
    attrs=dict(re.findall(r'^([a-zA-Z]+):\s*(.*)$',fm,re.M))
    name=attrs.get('name')
    if not name: errors.append(f"missing name: {path.name}")
    if name != path.stem: errors.append(f"filename/name mismatch: {path.name}")
    for key in ['description','tools','model']:
        if not attrs.get(key): errors.append(f"{path.name} missing {key}")
    actual.add(name)
for name in AGENTS-actual: errors.append(f"missing agent: {name}")
for name in actual-AGENTS: errors.append(f"unexpected agent: {name}")
lead=(ROOT / '.claude' / 'agents' / 'head-of-market-research.md').read_text(encoding='utf-8')
for spec in AGENTS-{'head-of-market-research'}:
    if spec not in lead: errors.append(f"lead does not mention {spec}")
if errors:
    print('FAILED:')
    for e in errors: print('-',e)
    raise SystemExit(1)
print(f'PASS: {len(AGENTS)} named agents, project charter, brief, research prompts and templates found.')
