Act as `head-of-market-research` and run a COMPLETE cross-disciplinary market research and commercial feasibility study for the project in `inputs/PROJECT_BRIEF.md`.

You MUST explicitly engage all six project specialists: `investment-banking`, `project-technology`, `syndications`, `real-estate-hospitality`, `ai-strategy`, and `environmental-technologies` (in parallel when possible). Their findings must be independently sourced, challenged by other specialists, reconciled and integrated.

Produce all required outputs under `outputs/` with live citations, precise source dates, assumptions register, scenario model specification, capital strategy, challenge log, risk ranking and a clear investment-committee verdict. Assess GO, CONDITIONAL GO, REDESIGN, NO-GO or INSUFFICIENT EVIDENCE. Do not confuse confidence with optimism.

Do not invent missing commercial data or fabricate consultant credentials. If inputs or tools are insufficient for an actual feasibility calculation, complete a rigorous evidence-gap-based PRE-FEASIBILITY STUDY instead, showing which missing numbers prevent an investment decision. Prioritize the top disconfirming evidence and primary research required.

At completion, give a short table of each specialist's verdict, main objection, source strength, and what needs to be verified next. Include unresolved dissent.
