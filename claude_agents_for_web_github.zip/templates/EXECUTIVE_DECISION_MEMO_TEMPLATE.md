# Executive Investment Committee Memo

**Project:**
**Study version and as-of date:**
**Recommendation:** GO / CONDITIONAL GO / REDESIGN / NO-GO / INSUFFICIENT EVIDENCE
**Research reliability:** HIGH / MODERATE / LOW, with explanation

## One-page investment decision
- The project thesis and target demand.
- What independent evidence supports it?
- What evidence contradicts it?
- Which three assumptions determine whether it works?
- What financing/permits/data are prerequisites?
- What changes or phase reduction improve risk-adjusted economics?

## Six specialist opinions
| Agent | Finding | Confidence | Critical challenge | Status |

## Financial metrics — only if computable
| Metric | Base | Downside | Upside | Formula and source assumptions |

## Capital and operating constraints

## Critical path and phase gates

## Risk ranking and dissent

## Management decisions required

## Open evidence gaps / procurement of expert reports

## Appendix: citations and model specifications
