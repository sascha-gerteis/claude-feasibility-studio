# Required specialist response shape

## Agent and decision
Agent ID, research coverage, as-of date, preliminary direction (support / conditional / reject / insufficient).

## Executive thesis (max 150 words)
Conclusions first; note two most important caveats.

## Evidence-backed findings
| Claim ID | Claim and numeric definition | Status: VERIFIED / CALCULATED / ESTIMATE / ASSUMPTION / UNKNOWN | Source ID + title/date/page or URL | Confidence and conflicts |

## Economic inputs
| Metric | Value or UNKNOWN | Unit / reporting period | Formula/source | Dependencies on other agents |

## Top alternatives / downside
How could the thesis fail? State at least 3 disconfirming tests.

## Cross-agent challenge
Three high-consequence assertions for other agents to defend or correct.

## Decision gates and additional diligence
Precise missing documents, surveys, contracts, legal sign-offs or calculations needed, ordered by value of information.

## Source and confidence limitations
Report stale data, paywalled data, company proprietary material that was inaccessible, and primary research still needed.
