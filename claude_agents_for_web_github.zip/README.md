# Claude Feasibility Studio — 7-agent investment research team

A reusable Claude Code setup for market research and integrated feasibility studies. Includes **one Head of Market Research + six specialist agents** inspired by professional analysis approaches associated with Goldman Sachs, McKinsey, Morgan Stanley, JLL, Anthropic and Bain Capital. These roles are simulations, **not affiliates or employees of those firms**.

## What you get
- Seven `.claude/agents/*.md` definitions with explicitly different research responsibilities and model allocation.
- Central project charter (`CLAUDE.md`), input form, run prompts and output templates.
- Mandatory fact/assumption distinctions, independent source verification, adversarial cross-checks, scenario modeling and investment-decision gates.
- No project data, reports or numeric investment forecasts have been fabricated. The team is **configured but not run**.

## Installation (Claude Code)
1. Extract this folder in a directory you want to use for project research. Open a terminal in the folder containing `CLAUDE.md` and `.claude/`.
2. Edit `inputs/PROJECT_BRIEF.md` with your actual project, location, phases, approved data and decision objectives. Add PDFs/files or accessible paths under `inputs/` if available.
3. Confirm Claude Code is installed and authenticated: `claude --version`.
4. Start the coordinator in the project directory: `claude --agent head-of-market-research`.
5. Paste the text of `prompts/START_FULL_STUDY.md` into the session, or prompt: `Run a complete six-specialist feasibility study using inputs/PROJECT_BRIEF.md. Follow CLAUDE.md and create the outputs listed in your agent instructions.`
6. Review `outputs/00_executive_decision_memo.md` and `outputs/assumption_register.csv` when the run finishes. A full study may require additional primary research and locally qualified professional verification.

You can also start ordinary `claude` and ask it explicitly to use the `head-of-market-research` subagent; using `--agent` makes the research director the main Claude Code session and enables it to delegate to its specialists. Current Claude Code docs: https://code.claude.com/docs/en/sub-agents

## Optional: full agent-team discussions
Claude Code also supports experimental *agent teams* that can message one another directly, but costs and coordination overhead are higher. To enable them in this project, create `.claude/settings.json` with:

```json
{"env":{"CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS":"1"}}
```

Then start `claude --agent head-of-market-research` and ask:

`For this full feasibility study, explicitly create an agent team with six teammates using the project subagent types investment-banking, project-technology, syndications, real-estate-hospitality, ai-strategy, environmental-technologies. Give each a discrete workstream and require cross-examination and synthesis.`

If agents launch as ordinary subagents instead, the study remains valid but uses centralized coordination rather than direct teammate chat. See https://code.claude.com/docs/en/agent-teams. This optional setting is deliberately not enabled automatically.

## Agent map
| Agent file / type | Purpose | Model |
| --- | --- | --- |
| `head-of-market-research` | Research planning, delegation, cross-examination, IC memo | opus |
| `investment-banking` | Project / equity economics, valuation, downside, IRR | opus |
| `project-technology` | Deliverability, procurement, critical path, integrated technology | sonnet |
| `syndications` | Debt/equity capital stack, funding constraints, lender readiness | opus |
| `real-estate-hospitality` | Hotels, retail, residential, MICE, comps, demand and absorption | sonnet |
| `ai-strategy` | AI/automation practicality, risk, data readiness and ROI | sonnet |
| `environmental-technologies` | Energy/water/waste/climate, technical economics and resilience | sonnet |

Change any `model:` line to `sonnet` to reduce costs, or `inherit` to use the caller's model. Usage depends on your Claude plan, model access and runtime tool permissions.

## Minimum expected analysis
- Verified factual baseline and research-source register.
- Competitor landscape with like-for-like comparisons and source dates.
- Market capture and segment-by-segment demand hypothesis.
- Capex/opex input requirements, revenue drivers, phase chronology, financing gates.
- Base/downside/upside sensitivities, quantified only where supported.
- AI and environmental technologies prioritized by demonstrable value and execution readiness.
- Financing diligence and a clear investment decision with conditions, adverse case and dissent.

## Files and privacy
`inputs/PROJECT_BRIEF.md` is a fillable template. `inputs/AQUAVERSE_EEC_EXAMPLE_UNVERIFIED.md` is an OPTIONAL sketch from earlier working context, explicitly **not confirmed** by primary project documents. Replace it with validated information before asking for a financial forecast. Company Drive access was unavailable when this pack was assembled; no corporate proprietary data was ingested.

Do not commit private projects, financials, personal information, API keys or commercial terms to a public repository. `.gitignore` helps guard obvious paths but is not a privacy guarantee.

## Quick validation
Run `python scripts/validate_agents.py` to check that the seven agent files, frontmatter names and key templates exist. This is a static package validation, not proof that Claude Code ran a full study.
